import { useState } from 'react';
import {
  ChevronRight, ChevronDown, Folder, FolderOpen,
  Plus, Edit2, Trash2, FolderPlus, MoreVertical
} from 'lucide-react';
import type { Category } from '../types';

interface Props {
  categories: Category[];
  selectedId: number | null;
  onSelect: (id: number | null) => void;
  onCreateRoot: () => void;
  onCreateSub: (parent: Category) => void;
  onEdit: (cat: Category) => void;
  onDelete: (cat: Category) => void;
  loading?: boolean;
}

function CategoryNode({
  category,
  level,
  selectedId,
  onSelect,
  onCreateSub,
  onEdit,
  onDelete,
}: {
  category: Category;
  level: number;
  selectedId: number | null;
  onSelect: (id: number | null) => void;
  onCreateSub: (cat: Category) => void;
  onEdit: (cat: Category) => void;
  onDelete: (cat: Category) => void;
}) {
  const [open, setOpen] = useState(true);
  const [showMenu, setShowMenu] = useState(false);
  const hasChildren = (category.children?.length ?? 0) > 0;
  const isSelected = selectedId === category.id;

  return (
    <div>
      <div
        className={`group flex items-center gap-1 px-2 py-[5px] rounded-lg cursor-pointer text-sm transition-all
          ${isSelected
            ? 'bg-indigo-600 text-white'
            : 'text-slate-700 hover:bg-slate-100'
          }`}
        style={{ paddingLeft: `${8 + level * 16}px` }}
        onClick={() => {
          onSelect(isSelected ? null : category.id);
          if (hasChildren) setOpen(o => !o);
        }}
      >
        {/* Expand icon */}
        <span className="w-4 h-4 flex-shrink-0">
          {hasChildren
            ? open
              ? <ChevronDown size={12} />
              : <ChevronRight size={12} />
            : null
          }
        </span>

        {/* Folder icon */}
        {isSelected
          ? <FolderOpen size={14} className="flex-shrink-0 text-indigo-200" />
          : <Folder size={14} className={`flex-shrink-0 ${level === 0 ? 'text-amber-500' : 'text-slate-400'}`} />
        }

        {/* Name */}
        <span className="flex-1 truncate font-medium" title={category.name}>
          {category.name}
        </span>

        {/* Product count */}
        {(category._count?.products ?? 0) > 0 && (
          <span className={`text-xs px-1.5 rounded-full flex-shrink-0 ${
            isSelected ? 'bg-indigo-500 text-indigo-100' : 'bg-slate-200 text-slate-500'
          }`}>
            {category._count?.products}
          </span>
        )}

        {/* Context menu button */}
        <div className="relative">
          <button
            onClick={e => { e.stopPropagation(); setShowMenu(v => !v); }}
            className={`p-0.5 rounded opacity-0 group-hover:opacity-100 transition-opacity ${
              isSelected ? 'hover:bg-indigo-500' : 'hover:bg-slate-200'
            }`}
          >
            <MoreVertical size={12} />
          </button>

          {showMenu && (
            <>
              <div className="fixed inset-0 z-10" onClick={() => setShowMenu(false)} />
              <div className="absolute right-0 top-5 z-20 bg-white border border-slate-200 rounded-lg shadow-lg py-1 w-48 text-xs">
                <button
                  onClick={e => { e.stopPropagation(); setShowMenu(false); onCreateSub(category); }}
                  className="flex items-center gap-2 w-full px-3 py-2 hover:bg-slate-50 text-slate-700"
                >
                  <FolderPlus size={13} /> Nueva subcategoría
                </button>
                <button
                  onClick={e => { e.stopPropagation(); setShowMenu(false); onEdit(category); }}
                  className="flex items-center gap-2 w-full px-3 py-2 hover:bg-slate-50 text-slate-700"
                >
                  <Edit2 size={13} /> Editar
                </button>
                <hr className="my-1 border-slate-100" />
                <button
                  onClick={e => { e.stopPropagation(); setShowMenu(false); onDelete(category); }}
                  className="flex items-center gap-2 w-full px-3 py-2 hover:bg-red-50 text-red-500"
                >
                  <Trash2 size={13} /> Eliminar
                </button>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Children */}
      {hasChildren && open && (
        <div>
          {category.children!.map(child => (
            <CategoryNode
              key={child.id}
              category={child}
              level={level + 1}
              selectedId={selectedId}
              onSelect={onSelect}
              onCreateSub={onCreateSub}
              onEdit={onEdit}
              onDelete={onDelete}
            />
          ))}
        </div>
      )}
    </div>
  );
}

export default function CategoryPanel({
  categories, selectedId, onSelect,
  onCreateRoot, onCreateSub, onEdit, onDelete, loading
}: Props) {
  // Build tree from flat list
  const roots = categories.filter(c => c.parentId === null);
  const addChildren = (cats: Category[]): Category[] =>
    cats.map(c => ({
      ...c,
      children: addChildren(categories.filter(ch => ch.parentId === c.id)),
    }));
  const tree = addChildren(roots);

  return (
    <aside className="w-60 flex-shrink-0 bg-white border-r border-slate-200 flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-slate-200 bg-slate-50">
        <h2 className="text-xs font-bold text-slate-500 uppercase tracking-wider">Categorías</h2>
        <button
          onClick={onCreateRoot}
          title="Nueva categoría"
          className="p-1 rounded-lg hover:bg-indigo-50 text-indigo-600 hover:text-indigo-700 transition-colors"
        >
          <Plus size={16} />
        </button>
      </div>

      {/* All products option */}
      <button
        onClick={() => onSelect(null)}
        className={`flex items-center gap-2 mx-2 mt-2 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
          selectedId === null
            ? 'bg-indigo-600 text-white'
            : 'text-slate-600 hover:bg-slate-100'
        }`}
      >
        <Folder size={14} className={selectedId === null ? 'text-indigo-200' : 'text-slate-400'} />
        <span>Todos los productos</span>
      </button>

      {/* Category tree */}
      <div className="flex-1 overflow-y-auto p-2 space-y-0.5">
        {loading ? (
          <div className="text-xs text-slate-400 px-3 py-4 text-center">Cargando...</div>
        ) : tree.length === 0 ? (
          <div className="text-xs text-slate-400 px-3 py-6 text-center">
            <FolderPlus size={24} className="mx-auto mb-2 text-slate-300" />
            Sin categorías
          </div>
        ) : (
          tree.map(cat => (
            <CategoryNode
              key={cat.id}
              category={cat}
              level={0}
              selectedId={selectedId}
              onSelect={onSelect}
              onCreateSub={onCreateSub}
              onEdit={onEdit}
              onDelete={onDelete}
            />
          ))
        )}
      </div>
    </aside>
  );
}
