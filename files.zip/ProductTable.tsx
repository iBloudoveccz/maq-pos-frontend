import { useState } from 'react';
import {
  Search, Plus, Edit2, Trash2, ToggleLeft, ToggleRight,
  Package, ChevronLeft, ChevronRight, Filter
} from 'lucide-react';
import type { Product } from '../types';

interface Props {
  products: Product[];
  total: number;
  page: number;
  limit: number;
  loading: boolean;
  search: string;
  onSearchChange: (v: string) => void;
  onPageChange: (p: number) => void;
  onNew: () => void;
  onEdit: (p: Product) => void;
  onDelete: (p: Product) => void;
  onToggleActive: (p: Product) => void;
  categoryName?: string;
}

export default function ProductTable({
  products, total, page, limit, loading,
  search, onSearchChange, onPageChange,
  onNew, onEdit, onDelete, onToggleActive, categoryName
}: Props) {
  const totalPages = Math.ceil(total / limit);
  const [hoveredId, setHoveredId] = useState<string | null>(null);

  return (
    <div className="flex flex-col h-full">
      {/* Top bar */}
      <div className="flex items-center gap-3 px-4 py-3 border-b border-slate-200 bg-white flex-shrink-0">
        {/* Search */}
        <div className="relative flex-1 max-w-sm">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            value={search}
            onChange={e => onSearchChange(e.target.value)}
            placeholder="Buscar por código, nombre, barcode..."
            className="w-full pl-9 pr-4 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400 transition-all"
          />
        </div>

        {/* Category filter label */}
        {categoryName && (
          <div className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-50 border border-indigo-200 rounded-lg">
            <Filter size={12} className="text-indigo-500" />
            <span className="text-xs font-medium text-indigo-700 truncate max-w-[150px]">{categoryName}</span>
          </div>
        )}

        <div className="ml-auto flex items-center gap-3">
          {/* Total count */}
          <span className="text-xs text-slate-500 hidden sm:block">
            {loading ? '...' : `${total} producto${total !== 1 ? 's' : ''}`}
          </span>

          {/* New button */}
          <button
            onClick={onNew}
            className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white text-sm font-medium rounded-lg hover:bg-indigo-700 transition-colors"
          >
            <Plus size={15} />
            <span>Nuevo</span>
          </button>
        </div>
      </div>

      {/* Table */}
      <div className="flex-1 overflow-auto">
        {loading ? (
          <div className="flex items-center justify-center h-full">
            <div className="text-center text-slate-400">
              <Package size={40} className="mx-auto mb-3 opacity-30 animate-pulse" />
              <p className="text-sm">Cargando productos...</p>
            </div>
          </div>
        ) : products.length === 0 ? (
          <div className="flex items-center justify-center h-full">
            <div className="text-center text-slate-400">
              <Package size={48} className="mx-auto mb-3 opacity-20" />
              <p className="text-sm font-medium text-slate-500">No hay productos</p>
              <p className="text-xs text-slate-400 mt-1">
                {search ? 'Prueba con otro término de búsqueda' : 'Crea el primer producto'}
              </p>
              <button
                onClick={onNew}
                className="mt-4 px-4 py-2 bg-indigo-600 text-white text-sm rounded-lg hover:bg-indigo-700 transition-colors"
              >
                + Nuevo producto
              </button>
            </div>
          </div>
        ) : (
          <table className="w-full text-sm border-collapse">
            <thead className="sticky top-0 z-10">
              <tr className="bg-slate-50 border-b border-slate-200">
                <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider w-10">#</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Código</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider min-w-[180px]">Nombre</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider hidden lg:table-cell">Categoría</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider hidden md:table-cell">Unidad</th>
                <th className="text-right px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Costo</th>
                <th className="text-right px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">P. Venta</th>
                <th className="text-right px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider hidden lg:table-cell">Margen</th>
                <th className="text-center px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider hidden md:table-cell">Estado</th>
                <th className="px-4 py-3 w-24"></th>
              </tr>
            </thead>
            <tbody>
              {products.map((p, idx) => {
                const margin = p.costPrice > 0
                  ? (((p.retailPrice - p.costPrice) / p.costPrice) * 100).toFixed(1)
                  : null;
                const isHovered = hoveredId === p.id;

                return (
                  <tr
                    key={p.id}
                    onMouseEnter={() => setHoveredId(p.id)}
                    onMouseLeave={() => setHoveredId(null)}
                    className={`border-b border-slate-100 transition-colors ${
                      isHovered ? 'bg-indigo-50/50' : idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/30'
                    } ${!p.isActive ? 'opacity-50' : ''}`}
                  >
                    <td className="px-4 py-3 text-xs text-slate-400 font-mono">
                      {(page - 1) * limit + idx + 1}
                    </td>
                    <td className="px-4 py-3">
                      <span className="font-mono text-xs bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md">
                        {p.code}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div>
                        <p className="font-medium text-slate-800 text-sm leading-tight">{p.name}</p>
                        {p.barcode && (
                          <p className="text-xs text-slate-400 font-mono">{p.barcode}</p>
                        )}
                        {p.spec && (
                          <p className="text-xs text-slate-400">{p.spec}</p>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-3 hidden lg:table-cell">
                      {p.category ? (
                        <span className="text-xs bg-amber-50 text-amber-700 border border-amber-200 px-2 py-0.5 rounded-full">
                          {p.category.name}
                        </span>
                      ) : (
                        <span className="text-xs text-slate-300">—</span>
                      )}
                    </td>
                    <td className="px-4 py-3 hidden md:table-cell text-xs text-slate-500">{p.unit ?? '—'}</td>
                    <td className="px-4 py-3 text-right font-mono text-sm text-slate-600">
                      S/. {p.costPrice.toFixed(2)}
                    </td>
                    <td className="px-4 py-3 text-right font-mono text-sm font-bold text-slate-800">
                      S/. {p.retailPrice.toFixed(2)}
                    </td>
                    <td className="px-4 py-3 text-right hidden lg:table-cell">
                      {margin !== null ? (
                        <span className={`text-xs font-bold ${
                          parseFloat(margin) > 20 ? 'text-emerald-600' :
                          parseFloat(margin) > 0  ? 'text-amber-600' : 'text-red-500'
                        }`}>
                          {margin}%
                        </span>
                      ) : <span className="text-slate-300 text-xs">—</span>}
                    </td>
                    <td className="px-4 py-3 text-center hidden md:table-cell">
                      <span className={`inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full font-medium ${
                        p.isActive
                          ? 'bg-emerald-50 text-emerald-700'
                          : 'bg-slate-100 text-slate-500'
                      }`}>
                        {p.isActive ? '● Activo' : '○ Inactivo'}
                      </span>
                    </td>
                    <td className="px-3 py-2">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => onEdit(p)}
                          title="Editar"
                          className="p-1.5 rounded-lg hover:bg-indigo-100 text-slate-400 hover:text-indigo-600 transition-colors"
                        >
                          <Edit2 size={13} />
                        </button>
                        <button
                          onClick={() => onToggleActive(p)}
                          title={p.isActive ? 'Desactivar' : 'Activar'}
                          className="p-1.5 rounded-lg hover:bg-amber-100 text-slate-400 hover:text-amber-600 transition-colors"
                        >
                          {p.isActive ? <ToggleRight size={13} /> : <ToggleLeft size={13} />}
                        </button>
                        <button
                          onClick={() => onDelete(p)}
                          title="Eliminar"
                          className="p-1.5 rounded-lg hover:bg-red-100 text-slate-400 hover:text-red-500 transition-colors"
                        >
                          <Trash2 size={13} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {/* Pagination */}
      {!loading && total > 0 && (
        <div className="flex items-center justify-between px-4 py-3 border-t border-slate-200 bg-white flex-shrink-0">
          <p className="text-xs text-slate-500">
            Mostrando {(page - 1) * limit + 1}–{Math.min(page * limit, total)} de {total}
          </p>
          <div className="flex items-center gap-1">
            <button
              onClick={() => onPageChange(page - 1)}
              disabled={page <= 1}
              className="p-1.5 rounded-lg hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed text-slate-600 transition-colors"
            >
              <ChevronLeft size={15} />
            </button>
            {Array.from({ length: Math.min(totalPages, 5) }, (_, i) => {
              const p = i + 1;
              return (
                <button
                  key={p}
                  onClick={() => onPageChange(p)}
                  className={`w-7 h-7 text-xs rounded-lg transition-colors ${
                    page === p
                      ? 'bg-indigo-600 text-white font-bold'
                      : 'hover:bg-slate-100 text-slate-600'
                  }`}
                >
                  {p}
                </button>
              );
            })}
            <button
              onClick={() => onPageChange(page + 1)}
              disabled={page >= totalPages}
              className="p-1.5 rounded-lg hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed text-slate-600 transition-colors"
            >
              <ChevronRight size={15} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
