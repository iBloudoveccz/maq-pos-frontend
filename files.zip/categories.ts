import axios from './axios'; // reutiliza la instancia con interceptores del auth
import type { Category, CreateCategoryDto, UpdateCategoryDto } from '@/features/products/types';

const BASE = '/categories';

export const categoriesApi = {
  getAll: (): Promise<Category[]> =>
    axios.get(BASE).then(r => r.data),

  getOne: (id: number): Promise<Category> =>
    axios.get(`${BASE}/${id}`).then(r => r.data),

  create: (dto: CreateCategoryDto): Promise<Category> =>
    axios.post(BASE, dto).then(r => r.data),

  update: (id: number, dto: UpdateCategoryDto): Promise<Category> =>
    axios.patch(`${BASE}/${id}`, dto).then(r => r.data),

  delete: (id: number): Promise<void> =>
    axios.delete(`${BASE}/${id}`).then(r => r.data),
};
