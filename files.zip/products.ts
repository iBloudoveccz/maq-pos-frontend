import axios from './axios';
import type {
  Product,
  CreateProductDto,
  UpdateProductDto,
  ProductFilters,
  PaginatedProducts,
} from '@/features/products/types';

const BASE = '/products';

export const productsApi = {
  getAll: (filters?: ProductFilters): Promise<PaginatedProducts> => {
    const params: Record<string, string | number | boolean> = {};
    if (filters?.search)     params.search     = filters.search;
    if (filters?.categoryId !== undefined && filters.categoryId !== null)
                              params.categoryId = filters.categoryId;
    if (filters?.isActive !== undefined) params.isActive = filters.isActive;
    if (filters?.page)       params.page       = filters.page;
    if (filters?.limit)      params.limit      = filters.limit;
    return axios.get(BASE, { params }).then(r => r.data);
  },

  getOne: (id: string): Promise<Product> =>
    axios.get(`${BASE}/${id}`).then(r => r.data),

  create: (dto: CreateProductDto): Promise<Product> =>
    axios.post(BASE, dto).then(r => r.data),

  update: (id: string, dto: UpdateProductDto): Promise<Product> =>
    axios.patch(`${BASE}/${id}`, dto).then(r => r.data),

  delete: (id: string): Promise<void> =>
    axios.delete(`${BASE}/${id}`).then(r => r.data),

  toggleActive: (id: string, isActive: boolean): Promise<Product> =>
    axios.patch(`${BASE}/${id}`, { isActive }).then(r => r.data),
};
